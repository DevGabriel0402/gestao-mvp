import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { FiSave, FiArrowLeft } from 'react-icons/fi'
import { toast } from 'react-toastify'
import { TopoPainelAdmin } from './TopoPainelAdmin'
import {
    Botao,
    Card,
    ContainerPagina,
    GrupoCampo,
    CampoBase,
    Rotulo,
    SelectBase,
    BotaoVoltar,
    Titulo
} from '../../estilos/componentes'
import { DropdownSelect } from '../../componentes/DropdownSelect'
import { criarOuAtualizarUsuarioSistema } from '../../servicos/usuarios_admin.servico'
import type { PapelUsuario } from '../../servicos/usuarios_admin.servico'

export function CriarUsuario() {
    const navegar = useNavigate()
    const [salvando, setSalvando] = useState(false)

    // Form
    const [uid, setUid] = useState('')
    const [nome, setNome] = useState('')
    const [email, setEmail] = useState('')
    const [papel, setPapel] = useState<PapelUsuario>('usuario')
    const [ativo, setAtivo] = useState(true)

    async function salvar() {
        if (!uid || !nome || !email) {
            toast.warn('Preencha UID, Nome e Email')
            return
        }

        setSalvando(true)
        try {
            await criarOuAtualizarUsuarioSistema(uid, {
                nome,
                email,
                papel,
                ativo
            })
            toast.success('Usuário criado com sucesso!')
            navegar('/admin/usuarios')
        } catch (e) {
            console.error(e)
            toast.error('Erro ao criar usuário')
        } finally {
            setSalvando(false)
        }
    }

    return (
        <ContainerPagina>
            <TopoPainelAdmin />

            <BotaoVoltar onClick={() => navegar('/admin/usuarios')} style={{ marginTop: 20 }}>
                <FiArrowLeft /> Voltar
            </BotaoVoltar>

            <Card style={{ marginTop: 10 }}>
                <Titulo style={{ marginBottom: 20 }}>Novo Usuário (Manual)</Titulo>

                <div style={{ background: '#fef3c7', padding: 12, borderRadius: 8, fontSize: 13, color: '#92400e', marginBottom: 20 }}>
                    <strong>Atenção:</strong> Como é um MVP, crie o usuário primeiro no
                    Authentication do Firebase Console, copie o <strong>User UID</strong> de lá e cole abaixo.
                </div>

                <GrupoCampo>
                    <Rotulo>User UID (do Firebase Auth)</Rotulo>
                    <CampoBase
                        value={uid}
                        onChange={(e) => setUid(e.target.value)}
                        placeholder="Ex: 5f9a2b..."
                    />
                </GrupoCampo>

                <GrupoCampo>
                    <Rotulo>Nome Completo</Rotulo>
                    <CampoBase
                        value={nome}
                        onChange={(e) => setNome(e.target.value)}
                    />
                </GrupoCampo>

                <GrupoCampo>
                    <Rotulo>E-mail</Rotulo>
                    <CampoBase
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        type="email"
                    />
                </GrupoCampo>

                <GrupoCampo>
                    <Rotulo>Papel</Rotulo>
                    <DropdownSelect
                        value={papel}
                        onChange={(v) => setPapel(v as PapelUsuario)}
                        options={[
                            { value: 'usuario', label: 'Usuário' },
                            { value: 'staff', label: 'Staff' },
                            { value: 'administrador', label: 'Administrador' }
                        ]}
                        placeholder="Selecione o papel..."
                    />
                </GrupoCampo>

                <GrupoCampo>
                    <Rotulo>Status</Rotulo>
                    <DropdownSelect
                        value={ativo ? 'true' : 'false'}
                        onChange={(v) => setAtivo(v === 'true')}
                        options={[
                            { value: 'true', label: 'Ativo' },
                            { value: 'false', label: 'Inativo (Bloqueado)' }
                        ]}
                    />
                </GrupoCampo>

                <div style={{ marginTop: 20, display: 'flex', justifyContent: 'flex-end' }}>
                    <Botao $variacao="primario" onClick={salvar} disabled={salvando}>
                        <FiSave /> {salvando ? 'Salvando...' : 'Criar Usuário'}
                    </Botao>
                </div>
            </Card>
        </ContainerPagina>
    )
}
