export function NaoEncontrado() {
    return <div style={{ padding: 16 }}>Página não encontrada.</div>
}
