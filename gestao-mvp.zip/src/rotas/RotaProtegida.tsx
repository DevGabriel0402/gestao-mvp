import { Navigate } from 'react-router-dom'
import { usarAutenticacao } from '../hooks/usarAutenticacao'
import type { PapelUsuario } from '../tipos/Usuario'

export function RotaProtegida({
    children,
    papeisPermitidos
}: {
    children: React.ReactNode
    papeisPermitidos?: PapelUsuario[]
}) {
    const { carregando, usuarioSistema } = usarAutenticacao()

    if (carregando) return <div style={{ padding: 16 }}>Carregando...</div>

    if (!usuarioSistema) return <Navigate to="/login" replace />

    if (papeisPermitidos && !papeisPermitidos.includes(usuarioSistema.papel)) {
        // Redirecionamento inteligente se o usuário não tiver permissão
        const destino = usuarioSistema.papel === 'administrador' || usuarioSistema.papel === 'staff'
            ? '/admin'
            : '/app'

        return <Navigate to={destino} replace />
    }

    return <>{children}</>
}
