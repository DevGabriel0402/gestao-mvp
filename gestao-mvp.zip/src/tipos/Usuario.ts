export type PapelUsuario = 'administrador' | 'staff' | 'usuario'

export type UsuarioSistema = {
    uid: string
    nome: string
    email: string
    papel: PapelUsuario
    ativo: boolean
}
