export type Oficina = {
    id: string
    nome: string
    ativa: boolean
    ordem?: number
}
